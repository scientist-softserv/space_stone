require "minitest"

Minitest.load_plugins
Minitest::PrideIO.pride!
