# frozen_string_literal: true

module HTTParty
  VERSION = '0.22.0'
end
