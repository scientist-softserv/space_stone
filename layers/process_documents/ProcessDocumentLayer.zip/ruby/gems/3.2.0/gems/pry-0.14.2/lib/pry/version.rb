# frozen_string_literal: true

class Pry
  VERSION = '0.14.2'.freeze
end
